To run 
1. Go to folder path

2. make virtual environment.
  $ virtualenv venv

3. Activate virtual environment
      - Go to foler path(inside venv)
      - $ source bin/activate

4. Install dependencies from requirements.txt file 
	$ pip3 install -r requirements.txt

5. Go to foler path where you find manage.py and runserver
	$ python3.6 manage.py runserver
	(It will start with localhost - 127.0.0.1:8000/home)

6. check database connection in Setting.py
 	DATABASE Section
 	[check database name in /etc/mysql/my.cnf]