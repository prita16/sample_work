from django.conf.urls import url
from django.views.decorators.csrf import csrf_exempt
from .views import *

urlpatterns = [
    url(r'^$', LandingPage.as_view(), name='LandingPage'),
]
