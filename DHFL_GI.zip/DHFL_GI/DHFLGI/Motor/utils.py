from django.core.exceptions import ValidationError
from .serializers import *

class UserObj(object):
    @classmethod
    def save_user_info(cls, data):
        form_data = data

        try:
            if 'csrfmiddlewaretoken' in form_data.keys():
                del form_data['csrfmiddlewaretoken']
        except:
            pass

        serializer = UserFormSerializer(data=form_data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return serializer.data
        else:
            serializer.is_valid(raise_exception=True)
            raise ValidationError(msg)
