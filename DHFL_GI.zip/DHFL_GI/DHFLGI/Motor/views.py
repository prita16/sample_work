# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import JsonResponse
from django.shortcuts import render
from django.shortcuts import redirect
from django.conf import settings
from django.views.generic import FormView, View
from .forms import *
from Accounts.models import *
from django.contrib.auth import authenticate, login
import logging
from django.urls import reverse
import hmac
import hashlib

DHFL_LOG = logging.getLogger(__name__)

# Create your views here.
class LandingPage(FormView):
	template_name = 'home.html'
	form_class = LandingPageForm

	def get(self, request, *args, **kwargs):
		# print(self.request.session['mobile_number'])
		if self.request.session.has_key('mobile_number'):
			return super().get(request, *args, **kwargs)
		else:
			return redirect(reverse('login'))

	def get_context_data(self, **kwargs):
		context = super().get_context_data(**kwargs)
		context['message'] = False
		if 'user_id' in self.request.session:
			print("^^^^^^^^^^^^^^^^^^^^^^^^context^^^^^^^^^^^^^^^^^^^^^^^ ", self.request.session['user_id'])
			_obj = User_Details.objects.get(pk=self.request.session['user_id'])
			context['vehicle_number'] = _obj.vehicle_number
			context['policy_flag'] = _obj.policy_flag
			context['message'] = True
		else:
			context['message'] = False
		return context

	def form_valid(self, form):
		data = form.cleaned_data
		self.request.session['user_id'] = form.save()
		print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ ", self.request.session['user_id'])
		self.request.session.modified= True
		if 'mobile_number' in self.request.session:
			_obj = User_Details.objects.get(pk=self.request.session['user_id'])
			_obj.mobile_number = self.request.session['mobile_number']
			_obj.save()
		return super().form_valid(form)

	def get_success_url(self):
		return reverse('LandingPage')


