from rest_framework import serializers
from .models import *

class UserFormSerializer(serializers.ModelSerializer):
    class Meta:
        model = User_Details
        fields = '__all__'
