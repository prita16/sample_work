# -*- coding: utf-8 -*-
from django import forms
from django.forms.utils import ErrorList
from django.utils.encoding import force_text
from django.utils.html import escape, format_html, format_html_join
from django.core.validators import MinLengthValidator
from Accounts.validators import Validator
from .models import *
from .utils import *

class ErrorListMsg(ErrorList):
	def __str__(self):
		return self.as_msg()

	def as_msg(self):
		if not self: return ''
		return format_html('<div class="uk-margin-small-top uk-alert-danger uk-text-small" uk-alert><a class="uk-alert-close" uk-close></a>{}</div>',format_html_join('', '{}', ((force_text(e),) for e in self)))


class LandingPageForm(forms.Form):
	vehicle_number = forms.CharField(max_length=16, required=True,
		widget=forms.TextInput(
			attrs={
				'class': 'uk-input uk-text-center uk-animation-slide-bottom uk-medium-large uk-width-1-1 uk-border-rounded uk-text-uppercase clear-text uk-text-medium',
				'placeholder': 'MH01AR5518',
				'autocomplete': 'off'
				}
		))

	policy_flag = forms.ChoiceField(choices=(('0', 'No'), ('1', 'Yes')), initial='1', widget=forms.RadioSelect(
		attrs={
			'class': 'uk-text-left form-radio',
			'placeholder': ''
			}
		))

	def __init__(self, *args, **kwargs):
		super(LandingPageForm, self).__init__(*args, **kwargs)
		self.error_class = ErrorListMsg

	def save(self):
		form_data = self.cleaned_data
		_dict = UserObj.save_user_info(form_data)
		return _dict['user_id']

	def clean_vehicle_number(self):
		number = self.cleaned_data.get('vehicle_number')
		number = number.replace(" ", "").replace("-", "").upper()
		validity_response  = Validator.validate('vehicle_number', number) or Validator.validate('vehicle_number2', number)
		if not validity_response:
			raise forms.ValidationError('Please provide a valid vehicle number')
		return number
