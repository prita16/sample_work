from django.db import models
import uuid 

class User_Details(models.Model):
	user_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
	mobile_number = models.CharField(max_length=10, blank=True)
	created_at = models.DateField(auto_now_add=True)
	updated_at = models.DateField(auto_now=True)
	vehicle_number = models.CharField(max_length=16)
	policy_flag = models.BooleanField(default=False)

