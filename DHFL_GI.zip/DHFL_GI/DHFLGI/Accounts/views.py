
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import JsonResponse, HttpResponseRedirect
from django.shortcuts import render
from django.shortcuts import redirect
from django.views.generic import FormView, View
from .forms import *
from django.urls import reverse
from .models import *
import json
import traceback
import sys
import time
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate, login
import logging
from django.contrib.auth.hashers import make_password

DHFL_LOG = logging.getLogger(__name__)


class LoginPage(FormView):
    template_name = 'login.html'
    form_class = LoginForm

    def get(self, request, *args, **kwargs):
        DHFL_LOG.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LOGIN")
        if 'mobile_number' in self.request.session:
            DHFL_LOG.info("request at:::  {}".format(time.time()))
            return redirect(reverse('LandingPage'))
        else:
            return super().get(request, *args, **kwargs)


    def form_valid(self, form):
        data = form.cleaned_data
        db_user = User.objects.values('username')
        user = authenticate(username=data['mobile_number'], password=data['password'])
        DHFL_LOG.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LOGIN")
        DHFL_LOG.info(user)
        if user is not None:
            self.request.session['mobile_number'] = data['mobile_number']
            self.request.session.modified = True
            return redirect(reverse('LandingPage'))
        else:
            print("not user")
            DHFL_LOG.info(user)
            return redirect(reverse('login'))

    def get_success_url(self):
        if 'mobile_number' in self.request.session:
            DHFL_LOG.info("request at:::  {}".format(time.time()))
            return redirect(reverse('LandingPage'))
        else:
            return redirect(reverse('login'))
 
class SignupPage(FormView):
    """Class Based View for render a signup page."""
    template_name = 'signup.html'
    form_class = SignUpForm

    def get(self, request, *args, **kwargs):
        if 'mobile_number' in self.request.session:
            DHFL_LOG.info("request at:::  {}".format(time.time()))
            return redirect(reverse('LandingPage'))
        else:
            return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        data = form.cleaned_data

        if data['_s_mobile_number'] and data['_s_password']:
            user = User.objects.create_user(username=data['_s_mobile_number'],
                                            password=data['_s_password'])
            user.save()
        return super().form_valid(form)
 
    def get_success_url(self):
        return reverse('login')
    

class Logout(View):
    def get(self, request):
        try:
            print("LOGOUT ...............")
            print(self.request.session['mobile_number'])
            if 'mobile_number' in request.session:
                del self.request.session['mobile_number']
                if 'user_id' in self.request.session:
                    del self.request.session['user_id']
            return redirect(reverse('login'))
        except Exception as e:
            DHFL_LOG.error(e)
            return redirect(reverse('login'))