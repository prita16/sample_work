# -*- coding: utf-8 -*-
from django import forms
from django.forms.utils import ErrorList
from django.utils.encoding import force_text
from django.utils.html import escape, format_html, format_html_join
from django.core.validators import MinLengthValidator
from .validators import Validator


class ErrorListMsg(ErrorList):
    def __str__(self):
        return self.as_msg()

    def as_msg(self):
        if not self: return ''
        return format_html('<div class="uk-margin-small-top uk-alert-danger uk-text-small" uk-alert><a class="uk-alert-close" uk-close></a>{}</div>',format_html_join('', '{}', ((force_text(e),) for e in self)))


class LoginForm(forms.Form):
	mobile_number = forms.CharField(
		max_length=10,
		widget=forms.TextInput(
			attrs={ 'class': 'uk-input uk-form-medium uk-text-center uk-border-rounded uk-width-1-1 uk-animation-slide-bottom',
					'placeholder': 'Enter Your Mobile Number' }),
		required=True,label='')
	
	password = forms.CharField(
		max_length=50,
		widget=forms.PasswordInput(
			attrs={ 'class': 'uk-input uk-form-medium uk-text-center uk-border-rounded uk-width-1-1 uk-animation-slide-bottom',
					'placeholder': 'Enter Your Password' }),
		required=True, label='')


	def clean_mobile_number(self):
		number = self.cleaned_data.get('mobile_number')
		validity_response  = Validator.validate('mobile_number', number)
		if not validity_response:
			raise forms.ValidationError('Please provide a valid mobile number')
		return number

	def __init__(self, *args, **kwargs):
		super(LoginForm, self).__init__(*args, **kwargs)
		self.error_class = ErrorListMsg


class SignUpForm(forms.Form):
	_s_mobile_number = forms.CharField(
		max_length=10,
		widget=forms.TextInput(
			attrs={ 'class': 'uk-input uk-form-medium uk-text-center uk-border-rounded uk-width-1-1 uk-animation-slide-bottom'}),
		required=True,label='')
	
	_s_password = forms.CharField(
		max_length=50,
		widget=forms.PasswordInput(
			attrs={ 'class': 'uk-input uk-form-medium uk-text-center uk-border-rounded uk-width-1-1 uk-animation-slide-bottom'}),
		required=True, label='')

	def clean_mobile_number(self):
		number = self.cleaned_data.get('_s_mobile_number')
		validity_response  = Validator.validate('_s_mobile_number', number)
		if not validity_response:
			raise forms.ValidationError('Please provide a valid mobile number.')
		return number

	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		self.error_class = ErrorListMsg



