import re

class Validator():

	@classmethod
	def validate(cls, field_name, input_value):
		import re
		regex_dict = {
			'vehicle_number': "^((AN)|(LD)|(AP)|(MH)|(AR)|(ML)|(AS)|(MN)|(BR)|(MP)|(CG)|(MZ)|(CH)|(NL)|(DD)|(OD)|(DL)|(PB)|(DN)|(PY)|(GA)|(RJ)|(GJ)|(SK)|(HR)|(TN)|(HP)|(TR)|(JH)|(TS)|(JK)|(UK)|(KA)|(UP)|(KL)|(WB)|(OR)|(UA))[0-9]{1,2}[A-Za-z]{0,3}[0-9]{1,4}$",
			'vehicle_number1': "^((AN)|(LD)|(AP)|(MH)|(AR)|(ML)|(AS)|(MN)|(BR)|(MP)|(CG)|(MZ)|(CH)|(NL)|(DD)|(OD)|(DL)|(PB)|(DN)|(PY)|(GA)|(RJ)|(GJ)|(SK)|(HR)|(TN)|(HP)|(TR)|(JH)|(TS)|(JK)|(UK)|(KA)|(UP)|(KL)|(WB)|(OR)|(UA))[0-9]{1,4}[A-Za-z]{0,3}[0-9]{1,6}$",
			'vehicle_number2': "^[A-Za-z]{1,3}[0-9]{1,4}$",
			'mobile_number': r'^[6-9]\d{9}$'
		}
		validator = re.compile(regex_dict[field_name])
		if not validator.match(input_value):
			return False
		else: 
			return True

	